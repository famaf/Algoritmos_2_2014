#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>

#include "array_helpers.h"
#include "sort.h"


#ifndef NDEBUG

static bool is_valid_position(unsigned int length, unsigned int i) {
    return (i < length);
}

#endif

unsigned long int get_comp_counter(void) {
    /* Needs implementation */
    return (0);
}

unsigned long int get_swap_counter(void) {
    /* Needs implementation */
    return (0);
}

void reset_counters(void) {
    /* Needs implementation */
}

void swap(int *a, unsigned int i, unsigned int j) {
/*
    Swap the value at position 'i' with the value at position 'j' in the
    array 'a'. The values 'i' and 'j' must be valid positions in the array.

*/
#ifndef NDEBUG
    /* Store the original values so later the assert can be made */
    int original_i = a[i], original_j = a[j];
#endif

    /* Needs implementation -- do not use original_i and original_j */

#ifndef NDEBUG
    /* Check postconditions */
    assert(original_i == a[j]);
    assert(original_j == a[i]);
#endif
    /* and the rest of the elements have not changed */
}

unsigned int min_pos_from(int *a, unsigned int length, unsigned int i) {
/*
    Return the position of the minimum value in the array 'a' starting
    at position 'i'. The array 'a' must have exactly 'length' elements,
    and 'i' must be a valid position in the array.

*/
    /* Check preconditions */
    assert(array_is_valid(a, length));
    assert(is_valid_position(length, i));

    unsigned int min = 0;

    /* Needs implementation */

    /* Check postconditions */
    assert(is_valid_position(length, min));
    return (min);
}

void selection_sort(int *a, unsigned int length) {
    assert(array_is_valid(a, length));

    /* Needs implementation */

    /* Check postconditions */
    assert(array_is_sorted(a, length));
}

void insertion_sort(int *a, unsigned int length) {
    assert(array_is_valid(a, length));

    /* Needs implementation */

    /* Check postconditions */
    assert(array_is_sorted(a, length));
}

void quick_sort(int *a, unsigned int length) {
    assert(array_is_valid(a, length));

    /* Needs implementation */

    /* Check postconditions */
    assert(array_is_sorted(a, length));
}
